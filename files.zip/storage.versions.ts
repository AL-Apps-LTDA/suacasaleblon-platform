/**
 * storage.versions.ts
 * Add this import in storage.ts: import { ... } from "./storage.versions"
 * Or paste these functions directly at the bottom of storage.ts
 *
 * Also add TrackVersion to types/music.ts (see bottom of this file)
 * And add `versions?: TrackVersion[]` to the Track type.
 */

import AsyncStorage from "@react-native-async-storage/async-storage";
import { Platform } from "react-native";
import { v4 as uuidv4 } from "uuid";
import { deleteAudioFile } from "@/lib/webAudioStorage";

const STORAGE_KEY = "@soundvault_library";

// ─── Type (copy this into types/music.ts) ─────────────────────────────────────
export interface TrackVersion {
  id: string;
  label: string;        // "Versão 1", "Demo acústico", etc.
  fileUri: string;
  duration: number;
  fileSize: number;
  createdAt: string;
  note?: string;
}
// ──────────────────────────────────────────────────────────────────────────────

async function getRawLibrary(): Promise<any> {
  const data = await AsyncStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : { tracks: [], projects: [], collections: [], settings: {} };
}

async function saveRawLibrary(library: any): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(library));
}

/** Add a new version to an existing track */
export async function addTrackVersion(
  trackId: string,
  version: Omit<TrackVersion, "id" | "createdAt">
): Promise<TrackVersion> {
  const library = await getRawLibrary();
  const track = library.tracks.find((t: any) => t.id === trackId);
  if (!track) throw new Error(`Track ${trackId} not found`);

  const newVersion: TrackVersion = {
    ...version,
    id: uuidv4(),
    createdAt: new Date().toISOString(),
  };

  if (!track.versions) track.versions = [];

  // Auto-label if not provided
  if (!newVersion.label) {
    newVersion.label = `Versão ${track.versions.length + 1}`;
  }

  track.versions.push(newVersion);
  await saveRawLibrary(library);
  return newVersion;
}

/** Remove a version from a track */
export async function removeTrackVersion(
  trackId: string,
  versionId: string
): Promise<void> {
  const library = await getRawLibrary();
  const track = library.tracks.find((t: any) => t.id === trackId);
  if (!track || !track.versions) return;

  const version = track.versions.find((v: TrackVersion) => v.id === versionId);
  if (version && Platform.OS === "web" && version.fileUri.startsWith("idb://")) {
    deleteAudioFile(version.fileUri.replace("idb://", "")).catch(console.warn);
  }

  track.versions = track.versions.filter((v: TrackVersion) => v.id !== versionId);
  await saveRawLibrary(library);
}

/** Update a version label or note */
export async function updateTrackVersion(
  trackId: string,
  versionId: string,
  updates: Partial<Pick<TrackVersion, "label" | "note">>
): Promise<TrackVersion | null> {
  const library = await getRawLibrary();
  const track = library.tracks.find((t: any) => t.id === trackId);
  if (!track || !track.versions) return null;

  const idx = track.versions.findIndex((v: TrackVersion) => v.id === versionId);
  if (idx === -1) return null;

  track.versions[idx] = { ...track.versions[idx], ...updates };
  await saveRawLibrary(library);
  return track.versions[idx];
}

/** Promote a version to become the main track audio (swap URIs) */
export async function promoteVersionToMain(
  trackId: string,
  versionId: string
): Promise<void> {
  const library = await getRawLibrary();
  const track = library.tracks.find((t: any) => t.id === trackId);
  if (!track || !track.versions) return;

  const version = track.versions.find((v: TrackVersion) => v.id === versionId);
  if (!version) return;

  // Save current main as a new version
  const currentMain: TrackVersion = {
    id: uuidv4(),
    label: "Versão anterior",
    fileUri: track.fileUri,
    duration: track.duration,
    fileSize: track.fileSize ?? 0,
    createdAt: new Date().toISOString(),
  };

  track.versions = track.versions
    .filter((v: TrackVersion) => v.id !== versionId)
    .concat(currentMain);

  // Promote the selected version
  track.fileUri = version.fileUri;
  track.duration = version.duration;
  track.fileSize = version.fileSize;

  await saveRawLibrary(library);
}
