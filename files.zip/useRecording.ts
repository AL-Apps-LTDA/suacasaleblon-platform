import { useState, useRef, useCallback } from "react";
import { Platform } from "react-native";
import { useAudioRecorder, AudioModule, RecordingPresets } from "expo-audio";
import { Paths, File, Directory } from "expo-file-system";
import { v4 as uuidv4 } from "uuid";
import { storeAudioFromUri } from "@/lib/webAudioStorage";

export interface RecordingResult {
  uri: string;
  duration: number;
  fileSize: number;
  name: string;
}

export function useRecording() {
  const recorder = useAudioRecorder(RecordingPresets.HIGH_QUALITY);
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startTimeRef = useRef<number>(0);
  const accumulatedRef = useRef<number>(0);

  const requestPermission = useCallback(async (): Promise<boolean> => {
    const status = await AudioModule.requestRecordingPermissionsAsync();
    setHasPermission(status.granted);
    return status.granted;
  }, []);

  const startRecording = useCallback(async (): Promise<boolean> => {
    const granted = hasPermission ?? (await requestPermission());
    if (!granted) return false;

    try {
      await recorder.prepareToRecordAsync();
      recorder.record();

      setIsRecording(true);
      setIsPaused(false);
      setElapsedSeconds(0);
      accumulatedRef.current = 0;
      startTimeRef.current = Date.now();

      timerRef.current = setInterval(() => {
        const extra = Math.floor((Date.now() - startTimeRef.current) / 1000);
        setElapsedSeconds(accumulatedRef.current + extra);
      }, 500);

      return true;
    } catch (err) {
      console.error("[useRecording] startRecording error:", err);
      return false;
    }
  }, [hasPermission, requestPermission, recorder]);

  const pauseRecording = useCallback(async () => {
    if (!isRecording || isPaused) return;
    recorder.pause();
    setIsPaused(true);
    accumulatedRef.current += Math.floor((Date.now() - startTimeRef.current) / 1000);
    if (timerRef.current) clearInterval(timerRef.current);
  }, [isRecording, isPaused, recorder]);

  const resumeRecording = useCallback(async () => {
    if (!isRecording || !isPaused) return;
    recorder.record();
    setIsPaused(false);
    startTimeRef.current = Date.now();
    timerRef.current = setInterval(() => {
      const extra = Math.floor((Date.now() - startTimeRef.current) / 1000);
      setElapsedSeconds(accumulatedRef.current + extra);
    }, 500);
  }, [isRecording, isPaused, recorder]);

  const stopRecording = useCallback(async (): Promise<RecordingResult | null> => {
    if (!isRecording) return null;
    if (timerRef.current) clearInterval(timerRef.current);

    const finalDuration = isPaused
      ? accumulatedRef.current
      : accumulatedRef.current + Math.floor((Date.now() - startTimeRef.current) / 1000);

    try {
      await recorder.stop();
    } catch (err) {
      console.error("[useRecording] stopRecording error:", err);
    }

    setIsRecording(false);
    setIsPaused(false);

    const rawUri = recorder.uri;
    if (!rawUri) return null;

    const timestamp = new Date();
    const defaultName = `Gravação ${timestamp.toLocaleDateString("pt-BR")} ${timestamp.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`;

    let finalUri = rawUri;

    if (Platform.OS === "web") {
      try {
        const trackId = uuidv4();
        finalUri = await storeAudioFromUri(trackId, rawUri);
      } catch (e) {
        console.warn("[useRecording] Failed to store web audio:", e);
      }
    } else {
      try {
        const trackId = uuidv4();
        const audioDir = new Directory(Paths.document, "audio");
        if (!audioDir.exists) await audioDir.create();
        const destFile = new File(audioDir, `${trackId}.m4a`);
        const sourceFile = new File(rawUri);
        await sourceFile.copy(destFile);
        finalUri = destFile.uri;
      } catch (e) {
        console.warn("[useRecording] Failed to copy file:", e);
        finalUri = rawUri;
      }
    }

    return {
      uri: finalUri,
      duration: finalDuration,
      fileSize: 0,
      name: defaultName,
    };
  }, [isRecording, isPaused, recorder]);

  const cancelRecording = useCallback(async () => {
    if (!isRecording) return;
    if (timerRef.current) clearInterval(timerRef.current);
    try {
      await recorder.stop();
    } catch {}
    setIsRecording(false);
    setIsPaused(false);
    setElapsedSeconds(0);
  }, [isRecording, recorder]);

  return {
    isRecording,
    isPaused,
    elapsedSeconds,
    hasPermission,
    requestPermission,
    startRecording,
    pauseRecording,
    resumeRecording,
    stopRecording,
    cancelRecording,
  };
}
